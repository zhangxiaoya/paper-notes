/**
 * File: example.cpp
 * Date: February 2013
 * Author: Dorian Galvez-Lopez
 * Description: example that shows how to compile a program with DLoopDetector.
 *   To see a functional example, get DLoopDetector_demo from
 *   http://webdiis.unizar.es/~dorian 
 */

#include <iostream>
#include <vector>
#include <string>

// OpenCV
#include <opencv/cv.h>
#include <opencv/highgui.h>

// DLoopDetector
#include "DLoopDetector.h" 
// defines BriefLoopDetector and Surf64LoopDetector

using namespace DLoopDetector;
using namespace DBoW2;
using namespace std;

int main(int argc, char *argv[])
{

  cout << "This is a toy example showing how to compile a program with"
    " DLoopDetector." << endl <<
    "For a full demo application, please get DLoopDetector_demo from:" 
    << endl <<
    "http://webdiis.unizar.es/~dorian" << endl;

  // creates a detector that uses SURF features
  Surf64LoopDetector detector;  

  // you must use detector.setDatabase() and detector.setVocabulary()
  // before using the detector. Check the full demo.
  

  return 0;  
}

